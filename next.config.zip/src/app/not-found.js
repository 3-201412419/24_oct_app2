export default function Notfound() {
    return(
        <h4>페이지를 찾을수 없습니다.</h4>
    )
}