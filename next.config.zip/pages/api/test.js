export default function handler(param, res){
        return res.status(200).json('hi');

}